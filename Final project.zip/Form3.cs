﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace total
{
    public partial class Form3 : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataReader reader;
        OleDbDataAdapter adapter;
        DataTable dt;
        public Form3()
        {
            InitializeComponent();
        }
        void GetItems()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\last.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM Items", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            GetItems();
            DataGridViewCheckBoxColumn checkboxcol = new DataGridViewCheckBoxColumn();
            checkboxcol.Width = 50;
            checkboxcol.Name = "check1";
            checkboxcol.HeaderText = "Checked";
            dataGridView1.Columns.Insert(0, checkboxcol);
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
          
            Itembox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
           /* Pricebox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();*/
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Quantitybox.Clear();
            Itembox.Clear();
            Pricebox.Clear();
        }
        int n = 0;
        int g = 0;

        private void button1_Click(object sender, EventArgs e)
        {
           // DataTable dt2 = new DataTable();
           // dt2.Columns.Add("ID");
          ////  dt2.Columns.Add("Item");
           // dt2.Columns.Add("Price");
           // foreach(DataGridView row in dataGridView1.Rows)
            {
                // bool isselect = Convert.ToBoolean(row.Cells["check1"].Value);
                //if (isselect)
                //  dt2.Rows.Add(row.Cells[1].Value, row.Cells[2].Value, (row.Cells[3].Value));
                // dataGridView2.DataSource = dt2;
                if (string.IsNullOrWhiteSpace(Quantitybox.Text))
                {
                    MessageBox.Show("Enter Quantity");
                }
                else
                {
                    if (int.TryParse(Quantitybox.Text, out int quantity))
                    {
                        int total = quantity * int.Parse(Pricebox.Text);
                        DataGridViewRow newRow = new DataGridViewRow();
                        newRow.CreateCells(dataGridView2);
                        newRow.Cells[0].Value = n + 1;
                        newRow.Cells[1].Value = Itembox.Text;
                        newRow.Cells[2].Value = Pricebox.Text;
                        newRow.Cells[3].Value = total;
                        dataGridView2.Rows.Add(newRow);
                        g += total;
                        Totalbox.Text = g.ToString();
                        n++;
                    }
                    else
                    {
                        MessageBox.Show("Invalid input for Quantity");
                    }
                }




            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
        }
    }
}
