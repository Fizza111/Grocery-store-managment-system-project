﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace total
{
    
    public partial class Form4 : Form
    {
        public int s;
        public int i, j, k;
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataReader reader;
        OleDbDataAdapter adapter;
        DataTable dt;

        public Form4()
        {
            InitializeComponent();
        }
        void GetEmployee()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\last.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM Employee", conn);
            conn.Open();
            adapter.Fill(dt);
            
            conn.Close();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\last.accdb";
            string username = usernamebox.Text;
            string password = passwordbox.Text;
            if(string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("please Enter both username and password");
            }
            else
            {
                using (OleDbConnection conn = new OleDbConnection(connectionString)) ;
                conn.Open();
                string query= "SELECT Password From Employee WHERE Name= @name";
                using(OleDbCommand command=new OleDbCommand(query,conn))
                {
                    
                    command.Parameters.AddWithValue("@username", username);
                    object result = command.ExecuteScalar();
                    if(result!=null && result.ToString()==password)
                    {
                        MessageBox.Show("Login successful");
                        Form3 f3 = new Form3();
                        f3.Show();
                        usernamebox.Clear();
                        passwordbox.Clear();

                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or password");
                    }
                    conn.Close();
                  
                }

            }
           

            
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /* Home h1= new Home();    
             h1.Show();*/
            string user, pass;
            user = usernamebox.Text;
            pass = passwordbox.Text;

            if (user == ("Admin") && pass == ("1234"))
            {
                 Home h1= new Home();    
             h1.Show();
                usernamebox.Clear();
                passwordbox.Clear();

            }
            else if(user=="" && pass=="")
            {
                MessageBox.Show("Enter the User Username and password");
            }
            else
            {
                MessageBox.Show("Invalid User name and Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            GetEmployee();
        }
    }
}
